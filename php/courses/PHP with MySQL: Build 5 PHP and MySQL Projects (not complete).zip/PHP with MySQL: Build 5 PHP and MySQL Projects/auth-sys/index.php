<?php require "includes/header.php"; ?>

hello from index
<?php require "includes/footer.php"; ?>
