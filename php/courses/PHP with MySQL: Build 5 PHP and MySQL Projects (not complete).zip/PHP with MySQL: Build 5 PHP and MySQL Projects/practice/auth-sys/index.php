<?php



class Index
{
}

echo "Hello wor";
echo '<a href="login.php">her</a>';
